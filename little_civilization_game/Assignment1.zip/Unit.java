/**
 * TODO
 * @author Jinyue Jiang 
 * @course
 * @version 1.0
 * @date Oct. 4, 2019 5:05:30 p.m. 
 * @copyright JJY
 *
 */
public abstract class Unit {
//private varibles
private Tile position;
private double hp;
private int moveRange;
private String faction;

//constructor with parameters
public Unit(Tile position,double hp,int moveRange,String faction ){
	//??????this.position=new Tile(this.position.getX,po);����Ҫnewһ��ô��
	this.position=position;
	this.hp=hp;
	this.moveRange=moveRange;
	this.faction=faction;
	
	//add units to listofunits and 

		if (!this.position.addUnit(this)) {
			throw new IllegalArgumentException();//use addUnit as a condition, if false then ptint error.
		}
};

//methods
	public final Tile getPosition() {
	return this.position;
}
	public final double getHP() {
	return this.hp;	
}
	public final String getFaction() {
	return this.faction;
}

//Methods to add unit to another place of tile.
	public boolean moveTo(Tile place) {
		if (this.moveRange+1>this.position.getDistance(this.position, place) && place.addUnit(this)) {
			this.position.removeUnit(this);//remove the unit from original tile
			position=place;
		return true;
		}return false;
	}

// method of recieving damage.
	public void receiveDamage(double damage) {
		if (this.position.isCity()) {
			damage*=0.9;
		}
		this.hp-=damage;
		
	if (this.hp<=0) {
		this.position.removeUnit(this);
	}
	}

//abastract method
	public abstract void takeAction(Tile tile);
	
//Override equal method
		@Override
		public boolean equals(Object obj) {
			if (obj instanceof Unit&&((Unit) obj).getPosition().getX()==this.getPosition().getX()&&((Unit) obj).getPosition().getY()==this.getPosition().getY()&&((Unit) obj).getHP()==this.getHP()&&((Unit) obj).getFaction().equals(this.getFaction())) {
				return true;//if two have same type, position, hp and faction.
			}return false;
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	












}
