/**
 * 
 * TODO
 * @author Jinyue Jiang 
 * @course
 * @version 1.0
 * @date Oct. 4, 2019 5:06:34 p.m. 
 * @copyright JJY
 *
 */
public class Settler extends Unit{
	
	//constructor
	public Settler(Tile position, double hp, String faction){
	super(position,hp,2,faction);
}


	
	//Method to impelement the abstract from superclass takeAction.
		@Override
	public void takeAction(Tile tile) {
		if (this.getPosition().getX()==tile.getX()&&this.getPosition().getY()==tile.getY()&&!tile.isCity()) {
			tile.foundCity();//build a city
			this.getPosition().removeUnit(this);//remove the settler from the unitlist.
		}
	}

	//override the equals from the unit
		@Override
	public boolean equals(Object obj) {
		if (obj instanceof Settler) {
			return super.equals(obj);
		}
		return false;
		}
		
	
}
