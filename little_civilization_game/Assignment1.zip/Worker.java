/**
 * 
 * TODO
 * @author Jinyue Jiang 
 * @course
 * @version 1.0
 * @date Oct. 4, 2019 5:06:29 p.m. 
 * @copyright JJY
 *
 */
public class Worker extends Unit{
	//local variable
	private int numJobsPerf=0;
	//constructor
	public Worker(Tile position, double hp, String faction){
		super(position,hp,2,faction);
}
	
	//Method to impelement the abstract from superclass takeAction.
			@Override
		public void takeAction(Tile tile) {
			if (this.getPosition().getX()==tile.getX()&&this.getPosition().getY()==tile.getY()&&!tile.isImproved()) {
				tile.buildImprovement();//build a city
				this.numJobsPerf++;
				if (this.numJobsPerf>=10) {
					this.getPosition().removeUnit(this);//remove the settler from the unitlist.
			}
		}
	}

			//override the equals method from militaryunit class.
			@Override
		public boolean equals(Object obj) {
			if (obj instanceof Worker&&((Worker) obj).numJobsPerf==this.numJobsPerf) {
				return super.equals(obj);
			}return false;
		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}
