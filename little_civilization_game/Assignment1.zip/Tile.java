/**
 * 
 * TODO
 * @author Jinyue Jiang 
 * @course
 * @version 1.0
 * @date Oct. 4, 2019 5:06:13 p.m. 
 * @copyright JJY
 *
 */
public class Tile {
//Private varibles
	private int xCo;
	private int yCo;
	private boolean isCity;
	private boolean isImp;
	private ListOfUnits unitList;
	
//Constructor
	public Tile (int x,int y) {
		this.xCo=x;
		this.yCo=y;
		this.isCity=false;
		this.isImp=false;
		this.unitList=new ListOfUnits();
	}
	
// Method to getX.
	public int getX() {
		return this.xCo;
	}
	
// Method to getY.
	public int getY() {
		return this.yCo;
	}
	
// Method shows if it is a city.
	public boolean isCity() {
		return this.isCity;
	}
	
// Method shows if it is improved.
	public boolean isImproved() {
		return this.isImp;
	}
	
// Method turns a tile to a city.
	public void foundCity() {
		this.isCity=true;
	}
	
// Method improve a building.
	public void buildImprovement() {
		this.isImp=true;
	}
	
// Method to add a unit.
	
	public boolean addUnit(Unit unit){
        if (unit instanceof MilitaryUnit) {
            for (int i=0;i<unitList.size();i++){
                if(unitList.get(i) instanceof MilitaryUnit){
                    if(!unitList.get(i).getFaction().equals(unit.getFaction()))
                        return false;
                }
            }
            unitList.add(unit);
            return true;
        } else{
            unitList.add(unit);
            return true;
        }
    }
		
	
//Method to remove unit.
	public boolean removeUnit(Unit a) {
		return this.unitList.remove(a);
	}
		
//Method to find the ememy faction.
	public Unit selectWeakEnemy(String a) {
		double lowestHP=Double.MAX_VALUE;
		int pointer=-1;
		for (int i = 0; i < unitList.size(); i++) {
			if (unitList.get(i).getFaction()!= a && unitList.get(i).getHP()<lowestHP) {
				lowestHP=unitList.get(i).getHP();
				pointer = i;
			}// compare and take the first lowestHP unit when it appears and output.
		}
		if (pointer>=0) {
			return unitList.get(pointer);
		}return null;
	}
		
// Method to calculate distance
	public double getDistance(Tile a,Tile b) {
		int x1=a.getX();
		int y1=a.getY();
		int x2=b.getX();
		int y2=b.getY();//set four local variables for calculations.
		return Math.sqrt(Math.pow((x1-x2), 2)+Math.pow((y1-y2), 2));
	}
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
