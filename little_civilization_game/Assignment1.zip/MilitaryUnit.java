/**
 * 
 * TODO
 * @author Jinyue Jiang 
 * @course
 * @version 1.0
 * @date Oct. 4, 2019 5:06:04 p.m. 
 * @copyright JJY
 *
 */
public abstract class MilitaryUnit extends Unit{
	//local variables
	private double attackDamage;
	private int attackRange;
	private int armor;
	
	//constructor
	public MilitaryUnit(Tile position, double hp,int moveRange, String faction, 
			double attackDamage,int attackRange, int armor){
		super(position,hp,moveRange,faction);
		this.attackDamage=attackDamage;
		this.attackRange=attackRange;
		this.armor=armor;
	}

	//Method override the takeaction.
	@Override
	public void takeAction(Tile tile) {
		if (!(this.getPosition().getDistance(this.getPosition(), tile)>=this.attackRange+1)) {
			double damage=this.attackDamage;
			Unit WeakEnemy = tile.selectWeakEnemy(this.getFaction());
			if(WeakEnemy!=null) {
			if (this.getPosition().isImproved()) {
				damage=1.05*this.attackDamage;
			}
			tile.selectWeakEnemy(this.getFaction()).receiveDamage(damage);
		}
		}
	}


	//methods to override recievedamage
	@Override
	public void receiveDamage(double damage) {
	damage*=100/(100+this.armor);
	super.receiveDamage(damage);
	}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
