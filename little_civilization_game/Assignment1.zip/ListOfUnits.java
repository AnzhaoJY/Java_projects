/**
 * 
 * TODO
 * @author Jinyue Jiang 
 * @course
 * @version 1.0
 * @date Oct. 4, 2019 5:05:51 p.m. 
 * @copyright JJY
 *
 */
public class ListOfUnits {
//variables
	private int size;
	private Unit[] unitsList;
	
//constructor
	public ListOfUnits() {
		this.unitsList=new Unit[10];
		this.size=0;
	};
	
//Method to return the size of list
	public int size() {
		return this.size;
	};
	
//Method to output the objects inside the array list.
	public Unit[] getUnits() {
		Unit[] newUnit = new Unit[10];
		for (int i = 0;unitsList[i]!=null&&i<this.size; i++) {
			newUnit[i]=unitsList[i];
		};
		return newUnit;
	};
	
//Method to output a specific place of the object inside the array.
	public Unit get(int a) {
	if (a>=0&&a<this.size) {
		return	unitsList[a];
	}throw new IndexOutOfBoundsException("IndexOutOfBoundsException");
	};
	
//Method to add a unit inside the list.
	public void add(Unit newUnit) {
		this.isFull();
		unitsList[size]=newUnit;
		this.size = this.size + 1;
	};
	
//Private method to show if the list if full or make it larger
	private void isFull() {
	if (unitsList[unitsList.length-1] != null) {
		int capacity = unitsList.length + unitsList.length/2 +1;
		Unit[] newList = new Unit[capacity];
		for (int i = 0; i < unitsList.length; i++) {
			newList[i]=this.unitsList[i];
		};
		this.unitsList=newList;
	};	
	};
	
//Method of indicating the position of one specific object.
	public int indexOf(Unit a) {
		for (int i = 0; i < this.size; i++) {
		if (this.unitsList[i].equals(a)) {
			return i;
		};
		};
		return -1;
	};
	
// Method to remove a unit from the list.
	public boolean remove(Unit a) {
		if (indexOf(a)>=0) {
			for (int i =indexOf(a); i < this.size; i++) {
				this.unitsList[i]=this.unitsList[i+1];
			} 
			this.size=this.size-1;
			return true;
		} 
		return false;
	}
	
// Method set the array for army.
	public MilitaryUnit[] getArmy() {
		int count =0;
		for (int i = 0; i < this.size; i++) {
		if (this.unitsList[i] instanceof MilitaryUnit) {
		count+=1;//explicit casting
		}
		}
		MilitaryUnit[]  newArmy= new MilitaryUnit[count];
		int index=0;
			for (int i = 0; i < unitsList.length; i++) {
			if (unitsList[i] instanceof MilitaryUnit) {
				newArmy[index]=(MilitaryUnit) unitsList[i];
				index++;
			}
			}//make sure no null position in the list.
			return newArmy;
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
