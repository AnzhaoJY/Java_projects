/**
 * 
 * TODO
 * @author Jinyue Jiang 
 * @course
 * @version 1.0
 * @date Oct. 4, 2019 5:06:24 p.m. 
 * @copyright JJY
 *
 */
public class Warrior extends MilitaryUnit{
//constructor
	public Warrior(Tile position,double hp,String faction){
		super(position,hp,1,faction,20.0,1,25);
	}
	
	//override the equals from the unit
			@Override
		public boolean equals(Object obj) {
			if (obj instanceof Warrior) {
				return super.equals(obj);
			}return false;
			}
			
}
