/**
 * 
 * TODO
 * @author Jinyue Jiang 
 * @course
 * @version 1.0
 * @date Oct. 4, 2019 5:06:18 p.m. 
 * @copyright JJY
 *
 */
public class Archer extends MilitaryUnit{
	private int numArrows;
	public Archer(Tile position,double hp,String faction){
		super(position,hp,2,faction,15.0,2,0);
		this.numArrows=5;
		
	}
	@Override
	public void takeAction(Tile tile) {
		if (this.numArrows==0) {
			this.numArrows=5;
		}else {
		super.takeAction(tile);
		this.numArrows-=1;
		}
	}
	

	@Override
public boolean equals(Object obj) {
	if (obj instanceof Archer&&((Archer) obj).numArrows==this.numArrows) {
		return super.equals(obj);
	}return false;
}
	

}
